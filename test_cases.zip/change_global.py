gvar = 0
def change_gvar():
    gvar = 1
    return

change_gvar()
print(gvar)