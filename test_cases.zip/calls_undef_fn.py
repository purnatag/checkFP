def result(n):
    res = factorial(n)/2
    return res

result(5)