def change_val(arg1):
    n = arg1
    n = n + 1
    print(n)
    return

change_val(1)