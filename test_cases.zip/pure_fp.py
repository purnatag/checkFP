def purefn(arg1, arg2):
    sum = arg1 + arg2
    return sum

print(purefn(3, 4))