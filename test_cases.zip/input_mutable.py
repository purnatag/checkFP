def change_val(arg1):
    print("Value of arg was", arg1)
    arg1 = 0
    print("Value changed to", arg1)
    return

change_val(1)